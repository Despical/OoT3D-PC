#pragma once

void InitializeAndroidGameHost();
