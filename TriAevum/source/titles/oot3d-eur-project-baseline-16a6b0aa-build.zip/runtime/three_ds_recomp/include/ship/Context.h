#pragma once

#include <string>
#include <memory>
#include <unordered_set>
#include <vector>
#include <unordered_map>
#include <spdlog/async.h>
#include "ship/audio/Audio.h"

namespace spdlog {
class logger;
}

namespace Ship {

class Console;
class ConsoleVariable;
class ControlDeck;
class CrashHandler;
class Window;
class Config;
class ResourceManager;
class FileDropMgr;
class EventSystem;
#ifdef ENABLE_SCRIPTING
class ScriptLoader;
class Keystore;
#endif

/**
 * @brief Central singleton context for the libultraship engine.
 *
 * Context owns and provides access to every major subsystem (resource management,
 * window, audio, controller, logging, configuration, scripting, etc.). Exactly one
 * Context should be alive at a time; use GetInstance() to retrieve it after creation.
 *
 * Typical usage:
 * @code
 * auto ctx = Ship::Context::CreateInstance("MyApp", "app", "config.json", archivePaths);
 * // ... use ctx->GetResourceManager(), ctx->GetWindow(), etc.
 * @endcode
 * @note Pointers to @code Context@endcode should not be stored as members. You should always access
 * @code Context@endcode via GetRawInstance
 */
class Context {
  public:
    /**
     * @brief Returns the currently active global Context instance.
     * @return Raw pointer to the Context. This should not be considered shared and should be considered invalid
     * once the scope ends.
     */
    static Context* GetRawInstance();
    static void DestroyInstance();
    /**
     * @brief Creates, initializes, and stores the global Context instance.
     *
     * Convenience factory that calls CreateUninitializedInstance() followed by Init().
     *
     * @param name              Human-readable application name.
     * @param shortName         Short application identifier used for paths and config keys.
     * @param configFilePath    Path to the JSON configuration file.
     * @param archivePaths      List of archive file or directory paths to mount.
     * @param validHashes       Set of acceptable game-version hash values (empty = all allowed).
     * @param reservedThreadCount Number of threads to keep free from the resource thread-pool.
     * @param audioSettings     Initial audio backend and channel configuration.
     * @param window            Optional pre-constructed Window to use; if nullptr a default is created.
     * @param controlDeck       Optional pre-constructed ControlDeck; if nullptr a default is created.
     * @return Raw pointer to the fully initialized Context.
     * @note The pointer returned by this function is only for convenience directly after creating an instance.
     */
    static Context* CreateInstance(const std::string& name, const std::string& shortName,
                                   const std::string& configFilePath, const std::vector<std::string>& archivePaths = {},
                                   const std::unordered_set<uint32_t>& validHashes = {},
                                   uint32_t reservedThreadCount = 1, AudioSettings audioSettings = {},
                                   std::shared_ptr<Window> window = nullptr,
                                   std::shared_ptr<ControlDeck> controlDeck = nullptr);

    /**
     * @brief Creates a Context that has not yet been initialized.
     *
     * Use this when you need finer control over initialization order; call Init() manually afterwards.
     *
     * @param name           Human-readable application name.
     * @param shortName      Short application identifier.
     * @param configFilePath Path to the JSON configuration file.
     * @return Raw pointer to the uninitialized Context.
     * @note The pointer returned by this function is only for convenience directly after creating an instance.
     */
    static Context* CreateUninitializedInstance(const std::string& name, const std::string& shortName,
                                                const std::string& configFilePath);

    /**
     * @brief Returns the platform-specific application bundle directory (e.g. the .app bundle on macOS).
     * @return Absolute path string, or an empty string on platforms without the concept of a bundle.
     */
    static std::string GetAppBundlePath();

    /**
     * @brief Returns the platform-specific directory where the application stores its data.
     * @param appName Override the application name used to build the path; defaults to the current app name.
     * @return Absolute path string.
     */
    static std::string GetAppDirectoryPath(const std::string& appName = "");

    /**
     * @brief Resolves a path relative to the application data directory.
     * @param path    Relative path to resolve.
     * @param appName Override the application name used to build the base path.
     * @return Absolute path string.
     */
    static std::string GetPathRelativeToAppDirectory(const std::string& path, const std::string& appName = "");

    /**
     * @brief Resolves a path relative to the application bundle directory.
     * @param path Relative path to resolve.
     * @return Absolute path string.
     */
    static std::string GetPathRelativeToAppBundle(const std::string& path);

    /**
     * @brief Searches common application directories for a file and returns its absolute path.
     * @param path    Filename or relative path to locate.
     * @param appName Override the application name used to search.
     * @return Absolute path to the first match found, or an empty string if not found.
     */
    static std::string LocateFileAcrossAppDirs(const std::string& path, const std::string& appName = "");

    /**
     * @brief Constructs a Context with the given identifiers but does not initialize subsystems.
     * @param name           Human-readable application name.
     * @param shortName      Short application identifier.
     * @param configFilePath Path to the JSON configuration file.
     */
    Context(std::string name, std::string shortName, std::string configFilePath);
    ~Context();

    /**
     * @brief Initializes all subsystems in the correct order.
     *
     * Called automatically by CreateInstance(). When using CreateUninitializedInstance(),
     * call this method manually after any custom pre-initialization setup.
     *
     * @param archivePaths        List of archive paths to mount.
     * @param validHashes         Acceptable game-version hashes.
     * @param reservedThreadCount Threads to reserve outside the resource pool.
     * @param audioSettings       Audio configuration.
     * @param window              Optional Window override.
     * @param controlDeck         Optional ControlDeck override.
     * @return true on success, false if any subsystem failed to initialize.
     */
    bool Init(const std::vector<std::string>& archivePaths, const std::unordered_set<uint32_t>& validHashes,
              uint32_t reservedThreadCount, AudioSettings audioSettings, std::shared_ptr<Window> window = nullptr,
              std::shared_ptr<ControlDeck> controlDeck = nullptr);

    /** @brief Returns the application-wide spdlog logger. */
    std::shared_ptr<spdlog::logger> GetLogger() const;
    /** @brief Returns the Config subsystem. */
    std::shared_ptr<Config> GetConfig() const;
    /** @brief Returns the ConsoleVariable subsystem (CVars). */
    std::shared_ptr<ConsoleVariable> GetConsoleVariables() const;
    /** @brief Returns the ResourceManager subsystem. */
    std::shared_ptr<ResourceManager> GetResourceManager() const;
    /** @brief Returns the ControlDeck subsystem. */
    std::shared_ptr<ControlDeck> GetControlDeck() const;
    /** @brief Returns the CrashHandler subsystem. */
    std::shared_ptr<CrashHandler> GetCrashHandler() const;
    /** @brief Returns the Window subsystem. */
    std::shared_ptr<Window> GetWindow() const;
    /** @brief Returns the developer Console subsystem. */
    std::shared_ptr<Console> GetConsole() const;
    /** @brief Returns the Audio subsystem. */
    std::shared_ptr<Audio> GetAudio() const;
    /** @brief Returns the FileDropMgr subsystem for handling drag-and-drop file events. */
    std::shared_ptr<FileDropMgr> GetFileDropMgr() const;
    /** @brief Returns the EventSystem subsystem. */
    std::shared_ptr<EventSystem> GetEventSystem() const;
#ifdef ENABLE_SCRIPTING
    /** @brief Returns the ScriptLoader subsystem. */
    std::shared_ptr<ScriptLoader> GetScriptLoader() const;
    /** @brief Returns the Keystore subsystem used for archive signature verification. */
    std::shared_ptr<Keystore> GetKeystore() const;
#endif

    /** @brief Returns the human-readable application name. */
    std::string GetName() const;
    /** @brief Returns the short application identifier. */
    std::string GetShortName() const;

    /**
     * @brief Initializes the spdlog logging backend.
     * @param debugBuildLogLevel   Log level used for debug builds.
     * @param releaseBuildLogLevel Log level used for release builds.
     * @return true on success.
     */
    bool InitLogging(spdlog::level::level_enum debugBuildLogLevel = spdlog::level::debug,
                     spdlog::level::level_enum releaseBuildLogLevel = spdlog::level::warn);

    /** @brief Initializes the Config subsystem, loading the config file from disk. */
    bool InitConfiguration();

    /** @brief Initializes the ConsoleVariable (CVar) subsystem and loads persisted values. */
    bool InitConsoleVariables();

    /**
     * @brief Initializes the ResourceManager and mounts the given archives.
     * @param archivePaths      Paths to archives or directories to mount.
     * @param validHashes       Acceptable game-version hashes; empty means all are valid.
     * @param reservedThreadCount Number of threads reserved outside the resource pool.
     * @param allowEmptyPaths   If true, initialization succeeds even when archivePaths is empty.
     * @return true on success.
     */
    bool InitResourceManager(const std::vector<std::string>& archivePaths = {},
                             const std::unordered_set<uint32_t>& validHashes = {}, uint32_t reservedThreadCount = 1,
                             const bool allowEmptyPaths = false);

    /**
     * @brief Initializes the ControlDeck subsystem.
     * @param controlDeck Optional pre-constructed ControlDeck; if nullptr a default is created.
     * @return true on success.
     */
    bool InitControlDeck(std::shared_ptr<ControlDeck> controlDeck = nullptr);

    /** @brief Initializes the CrashHandler subsystem. @return true on success. */
    bool InitCrashHandler();

    /**
     * @brief Initializes the Audio subsystem with the given settings.
     * @param settings Audio backend and channel configuration.
     * @return true on success.
     */
    bool InitAudio(AudioSettings settings);

    /** @brief Initializes the developer Console window. @return true on success. */
    bool InitConsole();

    /**
     * @brief Initializes the Window subsystem.
     * @param window Optional pre-constructed Window; if nullptr a default backend is selected.
     * @return true on success.
     */
    bool InitWindow(std::shared_ptr<Window> window = nullptr);

    /** @brief Initializes the FileDropMgr subsystem. @return true on success. */
    bool InitFileDropMgr();

    /** @brief Initializes the EventSystem subsystem. @return true on success. */
    bool InitEventSystem();

#ifdef ENABLE_SCRIPTING
    /**
     * @brief Initializes the ScriptLoader subsystem for runtime script compilation.
     * @param compileDefines  Preprocessor defines passed to the compiler.
     * @param codeVersion     Version tag embedded in compiled modules.
     * @param buildOptions    Raw compiler flags string.
     * @param includePaths    Additional include directories.
     * @param libraryPaths    Additional library search directories.
     * @param libraries       Libraries to link against compiled scripts.
     * @return true on success.
     */
    bool InitScriptLoader(std::unordered_map<std::string, std::string> compileDefines = {}, int codeVersion = 1,
                          std::string buildOptions = "-g -Wl", std::vector<std::string> includePaths = {},
                          std::vector<std::string> libraryPaths = {}, std::vector<std::string> libraries = {});

    /** @brief Initializes the Keystore used for verifying signed archives. @return true on success. */
    bool InitKeystore();
#endif

  protected:
    Context() = default;

  private:
    static std::unique_ptr<Context> mContext;

    std::shared_ptr<spdlog::logger> mLogger;
    // We only need the spdlog threadpool on release builds because of the async logger.
#ifndef _DEBUG
    std::shared_ptr<spdlog::details::thread_pool> mLogThreadPool;
#endif
    std::shared_ptr<Config> mConfig;
    std::shared_ptr<ConsoleVariable> mConsoleVariables;
    std::shared_ptr<ResourceManager> mResourceManager;
    std::shared_ptr<ControlDeck> mControlDeck;
    std::shared_ptr<CrashHandler> mCrashHandler;
    std::shared_ptr<Window> mWindow;
    std::shared_ptr<Console> mConsole;
    std::shared_ptr<Audio> mAudio;
    std::shared_ptr<FileDropMgr> mFileDropMgr;
    std::shared_ptr<EventSystem> mEventSystem;
#ifdef ENABLE_SCRIPTING
    std::shared_ptr<ScriptLoader> mScriptLoader;
    std::shared_ptr<Keystore> mKeystore;
#endif

    std::string mConfigFilePath;
    std::string mMainPath;
    std::string mPatchesPath;

    std::string mName;
    std::string mShortName;
};
} // namespace Ship
